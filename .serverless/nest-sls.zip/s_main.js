
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'zulfikar4568',
  applicationName: 'nest-sls',
  appUid: 'cHmSZZl39x37jl4kpr',
  orgUid: 'a87199e7-2b13-4ea5-a2e0-e3c3e0c57936',
  deploymentUid: 'f3df077f-da25-4a11-8541-e9cc6e88c4e2',
  serviceName: 'nest-sls',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'nest-sls-dev-main', timeout: 6 };

try {
  const userHandler = require('./dist/serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}